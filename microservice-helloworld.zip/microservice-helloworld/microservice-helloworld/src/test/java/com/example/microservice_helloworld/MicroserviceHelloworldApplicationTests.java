package com.example.microservice_helloworld;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroserviceHelloworldApplicationTests {

	@Test
	void contextLoads() {
	}

}
